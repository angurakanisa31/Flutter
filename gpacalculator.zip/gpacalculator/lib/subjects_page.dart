import 'package:flutter/material.dart';
import 'summary_page.dart';

class Subject {
  String name;
  int credit;
  String grade;

  Subject({required this.name, required this.credit, required this.grade});
}

class SubjectsPage extends StatefulWidget {
  final String username;

  SubjectsPage({required this.username});

  @override
  _SubjectsPageState createState() => _SubjectsPageState();
}

class _SubjectsPageState extends State<SubjectsPage> with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final creditController = TextEditingController();
  final customSubjectController = TextEditingController();

  String selectedYear = '1st Year';
  String selectedBranch = 'CSE';
  String selectedSubject = '';
  String selectedGrade = 'O';
  bool isCustomSubject = false;

  final List<String> years = ['1st Year', '2nd Year', '3rd Year', '4th Year'];
  final List<String> branches = ['CSE', 'ECE', 'EEE', 'MECH', 'CIVIL'];
  final List<String> grades = ['O', 'A+', 'A', 'B+', 'B', 'C', 'P', 'F'];

  List<Subject> subjects = [];
  late AnimationController _listAnimationController;

  final Map<String, Map<String, List<String>>> subjectMap = {
    '1st Year': {
      'CSE': ['Maths I', 'Physics', 'Programming Basics'],
      'ECE': ['Maths I', 'Physics', 'Circuit Theory'],
      'EEE': ['Maths I', 'Chemistry', 'Electrical Basics'],
      'MECH': ['Maths I', 'Engineering Graphics', 'Mechanics'],
      'CIVIL': ['Maths I', 'Surveying', 'Building Materials'],
    },
    '2nd Year': {
      'CSE': ['Data Structures', 'OOPs', 'Digital Logic'],
      'ECE': ['Signals', 'Analog Circuits', 'Digital Systems'],
      'EEE': ['Machines I', 'Control Systems', 'Digital Electronics'],
      'MECH': ['Thermodynamics', 'Fluid Mechanics', 'Machine Drawing'],
      'CIVIL': ['Structural Analysis', 'Concrete Tech', 'Hydraulics'],
    },
    '3rd Year': {
      'CSE': ['Operating Systems', 'DBMS', 'Computer Networks'],
      'ECE': ['Communication Systems', 'Microprocessors', 'VLSI'],
      'EEE': ['Power Systems', 'Microcontrollers', 'Drives'],
      'MECH': ['Dynamics', 'CAD/CAM', 'Heat Transfer'],
      'CIVIL': ['Geotechnical Engg', 'Transportation Engg', 'Design of Structures'],
    },
    '4th Year': {
      'CSE': ['AI', 'Machine Learning', 'Cloud Computing'],
      'ECE': ['Wireless Comm', 'Embedded Systems', 'IoT'],
      'EEE': ['Renewable Energy', 'Smart Grid', 'Power Electronics'],
      'MECH': ['Robotics', 'Industrial Engg', 'Automobile Engg'],
      'CIVIL': ['Construction Mgmt', 'Environmental Engg', 'Advanced Structures'],
    },
  };

  @override
  void initState() {
    super.initState();
    _listAnimationController = AnimationController(vsync: this, duration: Duration(milliseconds: 500));
  }

  @override
  void dispose() {
    _listAnimationController.dispose();
    creditController.dispose();
    customSubjectController.dispose();
    super.dispose();
  }

  void addSubject() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        subjects.add(
          Subject(
            name: isCustomSubject ? customSubjectController.text : selectedSubject,
            credit: int.parse(creditController.text),
            grade: selectedGrade,
          ),
        );
        _listAnimationController.forward(from: 0);
        creditController.clear();
        customSubjectController.clear();
        selectedGrade = 'O';
        isCustomSubject = false;
      });
    }
  }

  void goToSummary() {
    if (subjects.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => SummaryPage(
            username: widget.username,
            year: selectedYear,
            branch: selectedBranch,
            subjects: subjects,
          ),
        ),
      );
    }
  }

  Widget buildSubjectTile(Subject sub) {
    return FadeTransition(
      opacity: _listAnimationController,
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 4,
        margin: EdgeInsets.symmetric(vertical: 8),
        child: ListTile(
          leading: Icon(Icons.book, color: Colors.teal),
          title: Text(sub.name, style: TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('Credit: ${sub.credit}  |  Grade: ${sub.grade}'),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    List<String> availableSubjects = subjectMap[selectedYear]?[selectedBranch] ?? [];

    return Scaffold(
        appBar: AppBar(
        title: Text('Add Subjects'),
    backgroundColor: Colors.teal,
    ),
    body: Container(
    decoration: BoxDecoration(
    gradient: LinearGradient(
    colors: [Color(0xFFE0F7FA), Color(0xFFFFF9C4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    ),
    ),
    child: Padding(
    padding: EdgeInsets.all(16),
    child: SingleChildScrollView(
    child: Column(
    children: <Widget>[
    Text(
    'Hello, ${widget.username} 👋',
    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.teal[900]),
    ),
    SizedBox(height: 10),
    DropdownButtonFormField(
    value: selectedYear,
    items: years.map((year) => DropdownMenuItem(value: year, child: Text(year))).toList(),
    onChanged: (value) => setState(() => selectedYear = value.toString()),
    decoration: InputDecoration(labelText: 'Year of Study'),
    ),
    SizedBox(height: 10),
    DropdownButtonFormField(
    value: selectedBranch,
    items: branches.map((branch) => DropdownMenuItem(value: branch, child: Text(branch))).toList(),
    onChanged: (value) => setState(() => selectedBranch = value.toString()),
    decoration: InputDecoration(labelText: 'Branch'),
    ),
    SizedBox(height: 10),
    Form(
    key: _formKey,
    child: Card(
    color: Colors.white.withOpacity(0.95),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
    elevation: 6,
    child: Padding(
    padding: const EdgeInsets.all(16),
    child: Column(
    children: [
    if (!isCustomSubject)
    DropdownButtonFormField(
    value: availableSubjects.contains(selectedSubject)
    ? selectedSubject
        : (availableSubjects.isNotEmpty ? availableSubjects.first : null),
    items: availableSubjects
        .map((subj) => DropdownMenuItem(value: subj, child: Text(subj)))
        .toList(),
    onChanged: (value) => setState(() => selectedSubject = value.toString()),
    decoration: InputDecoration(labelText: 'Subject'),
    ),
    if (isCustomSubject)
    TextFormField(
    controller: customSubjectController,
    decoration: InputDecoration(labelText: 'Custom Subject Name'),
    validator: (value) => value!.isEmpty ? 'Enter subject name' : null,
    ),
    TextButton(
    onPressed: () => setState(() => isCustomSubject = !isCustomSubject),
    child: Text(isCustomSubject ? 'Choose from list' : 'Add custom subject'),
    ),
    SizedBox(height: 10),
    TextFormField(
    controller: creditController,
    decoration: InputDecoration(labelText: 'Credit'),
    keyboardType: TextInputType.number,
    validator: (value) => value!.isEmpty ? 'Enter credit' : null,
    ),
    SizedBox(height: 10),
    DropdownButtonFormField(
    value: selectedGrade,
    items: grades.map((grade) => DropdownMenuItem(value: grade, child: Text(grade))).toList(),
    onChanged: (value) => setState(() => selectedGrade = value.toString()),
    decoration: InputDecoration(labelText: 'Grade'),
    ),
    SizedBox(height: 16),
    ElevatedButton.icon(
    icon: Icon(Icons.add),
    label: Text('Add Subject'),
    style: ElevatedButton.styleFrom(
    backgroundColor: Colors.teal,
    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
    ),
    onPressed: addSubject,
    ),
    ],
    ),
    ),
    ),
    ),
    SizedBox(height: 20),
    Column(children: subjects.map((s) => buildSubjectTile(s)).toList()),
    if (subjects.isNotEmpty) ...[
    SizedBox(height: 20),
    ElevatedButton.icon(
    icon: Icon(Icons.check_circle),
      label: Text('View Summary'),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.teal,
        padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
      ),
      onPressed: goToSummary,
    ),
    ],
    ],
    ),
    ),
    ),
    ),
    );
  }
}