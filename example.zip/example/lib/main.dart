import 'package:flutter/material.dart' show AppBar, Axis, BorderRadius, BottomNavigationBar, BottomNavigationBarItem, BoxDecoration, BoxFit, BoxShadow, BuildContext, Card, Center, ClipRRect, Colors, Column, Container, EdgeInsets, ElevatedButton, Expanded, FontWeight, Icon, Icons, Image, InputDecoration, ListView, MainAxisAlignment, MainAxisSize, MaterialApp, MaterialPageRoute, Navigator, Offset, OutlineInputBorder, Padding, Radius, RoundedRectangleBorder, Row, Scaffold, ScaffoldMessenger, Size, SizedBox, SnackBar, State, StatefulWidget, StatelessWidget, Text, TextAlign, TextButton, TextEditingController, TextField, TextStyle, Widget, runApp;
import 'firebase_options.dart';
import 'package:firebase_core/firebase_core.dart';
Future<void> main() async {
  runApp(const CauveryWireApp());
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
}

class DefaultFirebaseOptions {
  static var currentPlatform;
}

class Firebase {
  static Future<void> initializeApp({required options}) async {}
}

class CauveryWireApp extends StatelessWidget {
  const CauveryWireApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cauvery Wire',
      debugShowCheckedModeBanner: false,
      home: const SplashScreen(),
    );
  }
}

// ---------------- SPLASH SCREEN -------------------

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.warehouse_rounded, size: 80, color: Colors.green),
            SizedBox(height: 20),
            Text(
              'Cauvery Wire',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------- LOGIN / REGISTER SCREEN -------------------

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _attemptLogin() {
    String email = _emailController.text.trim();
    String password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter both email and password'),
          backgroundColor: Colors.red,
        ),
      );
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomePage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock_outline, size: 80, color: Colors.green),
              const SizedBox(height: 20),
              const Text('Welcome to Cauvery Wire',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 30),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  prefixIcon: const Icon(Icons.email),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  prefixIcon: const Icon(Icons.lock),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  minimumSize: const Size.fromHeight(45),
                ),
                onPressed: _attemptLogin,
                child: const Text('Login'),
              ),
              TextButton(
                onPressed: _attemptLogin,
                child: const Text("Don't have an account? Register"),
              )
            ],
          ),
        ),
      ),
    );
  }
}


// ----------------- HOME PAGE WITH BOTTOM NAV ----------------------------

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  final String wireImage =
      "https://5.imimg.com/data5/SELLER/Default/2023/10/356307064/GK/BO/UM/8778670/carbon-steel-wire.png";

  @override
  Widget build(BuildContext context) {
    final List<Widget> _pages = [
      _homeContent(),
      const Center(child: Text('Orders Page')),
      const Center(child: Text('Profile Page')),
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.green,
        elevation: 0,
        leading: const Icon(Icons.menu, color: Colors.white),
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Cauvery Wire',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
            const SizedBox(width: 8),
            Image.network(
              'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Isi_mark.svg/2560px-Isi_mark.svg.png',
              height: 20,
              width: 28,
              color: Colors.white,
            ),
          ],
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 12),
            child: Icon(Icons.shopping_cart, color: Colors.white),
          ),
        ],
      ),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.grey,
        onTap: (int index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.receipt), label: "Orders"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }

  Widget _homeContent() {
    return ListView(
      children: [
        const SizedBox(height: 16),
        const Center(
          child: Text(
            'DAKSAKTHE POLY WRAPPING WIRE',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.green,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search products',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              fillColor: Colors.grey[200],
              filled: true,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Image.network(wireImage, height: 150, fit: BoxFit.contain),
        const SizedBox(height: 24),
        _sectionHeader(context, "Categories"),
        const SizedBox(height: 10),
        _buildCategories(context),
        const SizedBox(height: 24),
        _sectionHeader(context, "Products"),
        const SizedBox(height: 10),
        _buildProductScroll(context, wireImage),
      ],
    );
  }

  Widget _sectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          TextButton(
            onPressed: () {},
            child: const Row(
              children: [
                Text("View All", style: TextStyle(color: Colors.green)),
                Icon(Icons.arrow_forward_ios, size: 14, color: Colors.green),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildCategories(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _categoryCard("NORMAL OD"),
          const SizedBox(width: 12),
          _categoryCard("LESSOR OD"),
        ],
      ),
    );
  }

  Widget _categoryCard(String label) {
    return Expanded(
      child: Card(
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.network(
                "https://5.imimg.com/data5/SELLER/Default/2023/10/356307064/GK/BO/UM/8778670/carbon-steel-wire.png",
                height: 25,
              ),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.green,
                  fontWeight: FontWeight.bold,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProductScroll(BuildContext context, String imageUrl) {
    return SizedBox(
      height: 140,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: 5,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          return _productCard(imageUrl);
        },
      ),
    );
  }

  Widget _productCard(String imageUrl) {
    return Container(
      width: 110,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white,
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(2, 2))
        ],
      ),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Image.network(
              imageUrl,
              height: 80,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text("Wrapping Wire",
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
          ),
        ],
      ),
    );
  }
}